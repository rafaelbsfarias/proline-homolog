alter table "public"."partners" add column "category" text;


