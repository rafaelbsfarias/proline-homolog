alter table public.profiles
add column must_change_password boolean default false;

/*teste migrate*/