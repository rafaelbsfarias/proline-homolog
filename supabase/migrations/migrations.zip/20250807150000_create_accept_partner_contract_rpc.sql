CREATE OR REPLACE FUNCTION public.accept_partner_contract(
    p_partner_id uuid,
    p_content text,
    p_signed boolean
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO public.contract_partners (partner_id, content, signed)
    VALUES (p_partner_id, p_content, p_signed)
    ON CONFLICT (partner_id) DO UPDATE
    SET
        content = EXCLUDED.content,
        signed = EXCLUDED.signed,
        created_at = now();
END;
$$;
